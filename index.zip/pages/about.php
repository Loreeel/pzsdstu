<?php include ("../modules/header.php")?>
    <div class="container">
        <div class="row">
            About
        </div>
    </div>
<?php include ("../modules/footer.php")?>